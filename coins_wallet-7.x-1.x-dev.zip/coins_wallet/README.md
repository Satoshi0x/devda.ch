Coins wallet
============

This drupal module is a wallet system to be used with a devcoin daemon or whatever daemon system compatible with bitcoin.

The original Drupal 6 module made by m0Ray was not relased.
Here is the link to the discussion : http://drupal.org/node/1030762

This module is a complete rewrite for drupal 7 using bitcoin-php library.

Here is the link to the library used inside this code : https://github.com/mikegogulski/bitcoin-php

This code was made with the help of http://devda.ch that gave me the idea to make it and debug it.
